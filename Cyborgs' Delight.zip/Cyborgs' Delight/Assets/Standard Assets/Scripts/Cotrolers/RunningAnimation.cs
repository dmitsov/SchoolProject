using UnityEngine;
using System.Collections;

public class RunningAnimation : MonoBehaviour {

	void StartRunnig(bool hasStartedWalking){

	}
	
	void StopRunning(bool hasStopedWalking){
	
	}

}

